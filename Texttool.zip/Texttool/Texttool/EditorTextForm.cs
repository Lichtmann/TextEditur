﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Texttool.language;
using Texttool.TextManager;
using System.Text.RegularExpressions;
using System.Xml;
using System.IO;

namespace Texttool
{
    public partial class EditorTextForm : System.Windows.Forms.Form
    {
    #region #0# Variable; Instanzen
        //path
        private string m_WorkDirectory = Application.StartupPath;
        private string m_TextPath = Application.StartupPath + "\\Text";
        private string m_LangListFile = Application.StartupPath + "\\Text\\Language.xml";
        private string m_BaseDirectory = Application.StartupPath + "\\Text\\Base";
        private string m_ResaultDirectory = Application.StartupPath + "\\Text\\newtext";
        private string m_CacheFile = Application.StartupPath + "\\Text\\Base\\SumText.xml";
        //Auswahl der Gruppen
        private int m_cbb_groupindex = 1;
        //Instanzen 
        public static EditorTextForm m_instanz = null; //#######
        //Rows and Colmuns
        private static List<Sprache> l_list = null; //#Bug7#
        private static List<TextGroup> g_list = null;
        //TextBank
        DataSet TextBank = null;
        DataSet TextState = null;
        //XMLDocument
        XmlDocument TextDoc = null;
        //Search Tool
        private static SearchTool ST = null;
        #endregion

        #region Enum
        public enum TheTextStatus
        {
            Empty,

            LineEmpty = 1,

            Edited = 2,

            Changed = 3,

            Savechanged =4,
        }
        #endregion

        /// <summary>
        /// Konstruktor des EditorTextForm
        /// </summary>
        public EditorTextForm()
        {
            InitializeComponent();
            m_instanz = this;
            CheckProjectPath(Application.StartupPath);  //#Bug3##CheckProjektpath#
            OpenProject(File.Exists(m_CacheFile));      //-\Text\Base\SumText.xml [ready?]
            InitialDataGridView();
            //indexertest();
            //SearchText();           
            //g_list.IndexOf(group("A")).
        }
        
        private void indexertest()
        {
            Console.WriteLine(language("german").CultureName);
            Console.WriteLine(group("a").Name);            
        }

        #region #1# procedure of load Projeckt 

        /// <summary>
        /// Überprüfen die ausgewahlte Project, ob deren Pfad, Verzeichnis,Datei gibt.
        /// </summary>
        private void CheckProjectPath(string workpath)
        {
            this.m_WorkDirectory = workpath; //#Bug3-0##workpaht#
            this.m_TextPath = this.m_WorkDirectory + "\\Text";
            if (!Directory.Exists(m_TextPath)) { MessageBox.Show("Project NOT Found!"); return; } //#project#
            //-\Text [ready]---------------------------------------------------
            this.m_LangListFile = this.m_WorkDirectory + "\\Text\\Language.xml";
            if (!File.Exists(m_LangListFile)) { MessageBox.Show("XML File NOT Found!"); return; } //#Language#
            //-\Text\Language.xml [ready] -------------------------------------
            this.m_BaseDirectory = this.m_WorkDirectory + "\\Text\\Base";
            if (!Directory.Exists(m_BaseDirectory)) Directory.CreateDirectory(m_BaseDirectory);   //#BaseDir#
            //-\Text\Base [ready]---------------------------------------------
            this.m_ResaultDirectory = this.m_WorkDirectory + "\\Text\\newtext";
            if (!Directory.Exists(m_ResaultDirectory)) Directory.CreateDirectory(m_ResaultDirectory); //#Language#
            //-\Text\newtext [ready]------------------------------------------           
            this.m_CacheFile = this.m_WorkDirectory + "\\Text\\Base\\SumText.xml";
            //OpenProject(File.Exists(m_CacheFile));   //false new   #
        }

        /// <summary>
        /// Erstellen neue Project oder Load vorhere Projekt, je nach IsExisted false/true ist.
        /// </summary>
        /// <param name="IsExisted"></param>
        private void OpenProject(bool IsExisted)
        {
            l_list = Sprachelist_load(m_LangListFile);
            SpracheCheckListBox_Load();
            g_list = GroupList(m_TextPath);
            InitalSearchTool();
            OpenTextBank(l_list, g_list);
            if (!IsExisted) //New Project
            {
                LoadTextBank();
                CreateSumText(m_CacheFile, l_list, g_list); //#New Sum Text#
                LoadSumTexttoXMLDoc();
            }
            else
            {
                //LoadSumText();
                LoadTextBank();
                CreateSumText(m_CacheFile, l_list, g_list); //#Bug4##Compare the old Text#
                LoadSumTexttoXMLDoc();
            }
            CheckEmptyLine();
        }

        /// <summary>
        /// Create a SumText.xml, which ist a Combination of all Text_xx_XX.xml .
        /// </summary>
        /// <param name="filename"></param>
        /// <param name="ll"></param>
        /// <param name="gl"></param>
        private void CreateSumText(string filename, List<Sprache> ll, List<TextGroup> gl)
        {
            XmlTextWriter xtw = new XmlTextWriter(filename, System.Text.Encoding.UTF8);
            xtw.WriteStartDocument();
            xtw.Formatting = Formatting.Indented;
            xtw.Indentation = 2;
            xtw.WriteComment("File with all Language Text - " + DateTime.Now.ToString("dd.MM.yyyy  HH:mm:ss"));
            xtw.WriteStartElement("Text");
            //0----------------------------------------
            for (int i = 1; i < gl.Count; i++)
            {
                //1-TextGroup--------------------------
                xtw.WriteStartElement("TextGroup");
                xtw.WriteAttributeString("Group", gl[i].Group);
                xtw.WriteAttributeString("Count", gl[i].Count.ToString());
                xtw.WriteAttributeString("Name", gl[i].Name);
                //TextBank.Tables[i-1]    //group[1] "A" <=> Table[0] "A"
                //2-TextElement------------------------
                for (int j = 0; j < gl[i].Count; j++)     //<TextElement Index="j(0)" Text="A{0}(de-DE als Standard)" />
                {
                    if (AreAllTextColumnsEmpty(TextBank.Tables[i - 1].Rows[j], ll)) continue;
                    xtw.WriteStartElement("TextElement");
                    xtw.WriteAttributeString("Index", j.ToString());
                    xtw.WriteAttributeString("Text", TextBank.Tables[i - 1].Rows[j][1].ToString());
                    //3-Language-----------------------
                    int k = 0;
                    foreach (var sp in ll)                  //#Bug7#
                    {
                        k++;
                        string text = TextBank.Tables[i - 1].Rows[j][k].ToString();
                        xtw.WriteStartElement("Language");
                        xtw.WriteAttributeString("IntNumber", sp.InternalNumber.ToString());
                        if (string.IsNullOrEmpty(text))
                        {
                            xtw.WriteAttributeString("Status", 0.ToString());
                        }
                        else
                        {
                            xtw.WriteAttributeString("Status", 1.ToString());
                        }
                        xtw.WriteAttributeString("LanguageText", text);

                        xtw.WriteEndElement();
                    }

                    //3--------------------------------
                    xtw.WriteEndElement();
                }
                //2------------------------------------
                xtw.WriteEndElement();
                //1------------------------------------
            }
            //0----------------------------------------
            xtw.WriteEndElement();
            xtw.WriteEndDocument();
            xtw.Flush();
            xtw.Close();
        }

        /// <summary>
        /// Erstellen XMLDocument Instanz, Kopie SumText.xml to SumTExttemp.xml. TextDoc handlt SumTExttemp.xml.
        /// </summary>
        private void LoadSumTexttoXMLDoc()
        {
            TextDoc = new XmlDocument();
            TextDoc.Load(m_CacheFile);
            TextDoc.Save(TempFileName(m_CacheFile));
            TextDoc.Load(TempFileName(m_CacheFile));
        }

        /// <summary>
        /// Default Datatble with Datagridview bind. Set Display Still.
        /// </summary>
        private void InitialDataGridView()
        {
            //#1 DataQuelle verbinden---------------------------
            cbbGroup.SelectedIndex = m_cbb_groupindex;
            //1//dataGridView1.DataSource = TextBank;
            //1//dataGridView1.DataMember = g_list[m_groupindex].Group;
            dataGridView1.DataSource = TextBank.Tables[m_cbb_groupindex - 1];
            //#2 dataGridView1.Columns[0].SortMode = DataGridViewColumnSortMode.NotSortable; //#sortmode#            
            //#3 3 Standard Sprache color-------------------------
            dataGridView1.Columns[3].Frozen = true;
            dataGridView1.Columns[1].HeaderCell.Style.BackColor = Color.Turquoise;
            dataGridView1.Columns[2].HeaderCell.Style.BackColor = Color.Turquoise;
            dataGridView1.Columns[3].HeaderCell.Style.BackColor = Color.Turquoise;
            //#4 Spaltwidth--------------------- 
            ResetSpaltwidth();
            //#5 Leer Zeilen
            
            SetColumnHeadText(); //#Bug6#           

        }

        #endregion

        #region #2# Elements of EditorTextForm

        #region#2##5# dataGridView1: Einstellung, Darstellung, ChangeEvent,

        /// <summary>
        /// Text wird bearbeited
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void dataGridView1_CellValueChanged(object sender, DataGridViewCellEventArgs e)
        {
            //-Cells Color--------------------------------------------------------------------------------------
            // Color Change with [Color Name] or {Html Hex Code] or [RGB mit Alpha](0-255, but default wenn <=254)
            if (e.RowIndex < 0) return;
            dataGridView1.Rows[e.RowIndex].Cells[e.ColumnIndex].Style.BackColor = m_ChangedCellsColor;
            //dataGridView1.Rows[e.RowIndex].Cells[e.ColumnIndex].Style.BackColor = (Color)ColorTranslator.FromHtml("#FFA07A");
            //dataGridView1.Rows[e.RowIndex].Cells[e.ColumnIndex].Style.BackColor = Color.FromArgb(255, 69, 0);
            string Textid = dataGridView1.Rows[e.RowIndex].Cells[0].Value.ToString();
            int t_index = IDtoIndex(Textid);
            TextState.Tables[m_cbb_groupindex - 1].Rows[t_index][e.ColumnIndex] = "3"; //#Bug13#Changed

            //-Changed Text save in List-------------------------------------------------------------------------
            string text = dataGridView1.Rows[e.RowIndex].Cells[e.ColumnIndex].Value.ToString();
            if (!String.IsNullOrEmpty(text))
            {
                bool isNewLine;
                dataGridView1.Rows[e.RowIndex].DefaultCellStyle.BackColor = Color.White;
                int r = e.RowIndex;         // r == Index of Textelement
                int c_l = e.ColumnIndex - 1; // c == IntnalNumber of Language
                XmlNode textnode = GetTextNodeofChangedCell(g_list[m_cbb_groupindex].Group/*"A"*/, r, c_l, out isNewLine);
                if (isNewLine)  //#Bug1##InsertnewLine#
                {
                    XmlElement newText = NewTextElement(TextDoc, e.RowIndex);
                    if (c_l == 0) { newText.SetAttribute("Text", text); }
                    newText.ChildNodes[c_l].Attributes["LanguageText"].Value = text;
                    //-Insert Text ---------
                    //-Position: index(r)-----
                    int Textcount = textnode.ChildNodes.Count;
                    if (r == 0 || Textcount == 0) { textnode.PrependChild(newText); }  //Start of list
                    else                                                                //end of list
                    {
                        if (int.Parse(textnode.LastChild.Attributes["Index"].Value) < r) { textnode.AppendChild(newText); }
                        else                                                            // mittel of list
                        {
                            for (int i = 0; i < Textcount - 1; i++)
                            {
                                if (int.Parse(textnode.ChildNodes[i].Attributes["Index"].Value) > r)
                                {
                                    textnode.InsertBefore(newText, textnode.ChildNodes[i]);
                                    break;
                                }
                            }
                        }
                    }
                    //-Insert Text------------


                }
                else
                {
                    textnode.Attributes["LanguageText"].Value = text;
                }
                TextDoc.Save(m_CacheFile.Replace(".xml", "") + "temp" + ".xml"); //#Bug1##SaveSumtemp#
                Console.WriteLine("Text ändern: " + TextBank.Tables[m_cbb_groupindex - 1].Rows[e.RowIndex][e.ColumnIndex]);
            }
            //-Record the Change position and Text to a list -------------- //#todo##Auf5#


        }

        private void dataGridView1_SelectionChanged(object sender, EventArgs e)
        {

        }

        private void SetColumnHeadText()  //#Bug6#
        {
            for (int i = 1; i < dataGridView1.Columns.Count; i++)
            {
                dataGridView1.Columns[i].HeaderText = LNametoColName(dataGridView1.Columns[i].Name);
            }
        }

        private void ResetSpaltwidth()
        {
            dataGridView1.Columns[1].AutoSizeMode = DataGridViewAutoSizeColumnMode.DisplayedCells;
            dataGridView1.Columns[2].AutoSizeMode = DataGridViewAutoSizeColumnMode.DisplayedCells;
            dataGridView1.Columns[3].AutoSizeMode = DataGridViewAutoSizeColumnMode.DisplayedCells;
            if (dataGridView1.Columns[1].Width > 500)
            {
                dataGridView1.Columns[1].AutoSizeMode = DataGridViewAutoSizeColumnMode.None;
                dataGridView1.Columns[2].AutoSizeMode = DataGridViewAutoSizeColumnMode.None;
                dataGridView1.Columns[3].AutoSizeMode = DataGridViewAutoSizeColumnMode.None;
                dataGridView1.Columns[1].Width = 300;
                dataGridView1.Columns[2].Width = 300;
                dataGridView1.Columns[3].Width = 300;
            }
            Console.WriteLine("width: " + dataGridView1.Columns[1].Width);
        }

        /// <summary>
        /// Markieren die leere Zeilen
        /// </summary>
        private void CheckEmptyLine()
        {
            for (int g = 1; g < g_list.Count; g++)
            {
                for (int i = 0; i < TextBank.Tables[g-1].Rows.Count; i++)
                {
                    if (AreAllTextColumnsEmpty(TextBank.Tables[g-1].Rows[i], l_list)) //#Bug7#
                    {
                        TextState.Tables[g-1].Rows[i][0] = "1"/*TheTextStatus.LineEmpty*/;
                        //dataGridView1.Rows[i].DefaultCellStyle.BackColor = Color.Silver;
                        //dataGridView1.Rows[i].Cells[0].Style.BackColor = Color.Red;
                    }
                }
            }
        }

        #endregion

        #region #3# Read Language.xml, Load [Languagelist Panel], Event[Set Visibility of Language]

        /// <summary>
        /// Sprachelist einlesen, aus Language.xml 
        /// </summary>
        /// <param name="m_File"></param>
        /// <returns></returns>
        private List<Sprache> Sprachelist_load(string m_File) //#Bug7#
        {       
             List<Sprache> Sprachelist; /*= new List<language>();*/            
             XmlTextReader reader = new XmlTextReader(m_File);
             Sprachelist = new List<Sprache>();
             ReadLanguageXML(reader, Sprachelist);
             reader.Close();
            
            return Sprachelist;
        }

        private void SpracheCheckListBox_Load()
        {
            //##
            for (int i = 0; i < l_list.Count; i++)
            {
                if (i <= 2)
                {
                    clb_Standard.Items.Add(l_list[i].Name, true);
                }
                else
                {
                    clb_Auswahl.Items.Add(l_list[i].Name, true);
                    //ll.Sprachelist[i].Visible = false;
                }
            }
            splitContainer1.SplitterDistance = 1; //#Languagelist##Panel#
        }

        private void ReadLanguageXML(XmlTextReader reader, List<Sprache> Sprachelist)
        {
            try
            {
                while (reader.Read())
                {
                    if (reader.NodeType == XmlNodeType.Element && reader.Name == "LanguageDescr")
                    {
                        Sprache readlanguag = new Sprache();
                        readlanguag.Name = reader.GetAttribute("Name");
                        while (reader.Read())
                        {
                            if (reader.Name == "CultureName")
                            {
                                readlanguag.CultureName = reader.ReadString().ToString();
                            }
                            else if (reader.Name == "InternalNumber")
                            {
                                readlanguag.InternalNumber = int.Parse(reader.ReadString());
                            }
                            else if (reader.Name == "Text")
                            {
                                readlanguag.Text = reader.ReadString();
                            }
                            else if (reader.NodeType == XmlNodeType.EndElement && reader.Name.Equals("LanguageDescr"))
                                break;
                        }
                        if (readlanguag.InternalNumber != -1) Sprachelist.Add(readlanguag);
                        //readlanguag.clear();               
                    }
                    else if (reader.NodeType == XmlNodeType.EndElement && reader.Name.Equals("LanguageList"))
                        break;
                }
            }
            catch (Exception)
            {
                MessageBox.Show("XML Falsh！");
            }
        }


        /// <summary>
        /// save the changed Visiblity of Language in List of Sprache.Visible
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btn_set_Click(object sender, EventArgs e)
        {
            for (int j = 0; j < clb_Standard.Items.Count; j++)
            {
                Console.WriteLine(clb_Standard.Items[j].ToString() + clb_Standard.GetItemChecked(j));
                if (l_list[j].Visible != clb_Standard.GetItemChecked(j)) // if changed? //#Bug7#
                {
                    l_list[j].Visible = clb_Standard.GetItemChecked(j);
                }
            }

            for (int j = 0; j < clb_Auswahl.Items.Count; j++)
            {
                Console.WriteLine(clb_Auswahl.Items[j].ToString() + clb_Auswahl.GetItemChecked(j));
                if (l_list[j + 3].Visible != clb_Auswahl.GetItemChecked(j)) // if changed?
                {
                    l_list[j + 3].Visible = clb_Auswahl.GetItemChecked(j);
                }
            }
            Sprache_visible();
        }

        /// <summary>
        /// Set Visiblity of Language accroding to Sprache.visible
        /// </summary>
        private void Sprache_visible()
        {
            for (int i = 0; i < l_list.Count; i++)
            {
                dataGridView1.Columns[i + 1].Visible = l_list[i].Visible;
            }
        }

        /// <summary>
        /// Event: Auswahl list: all checkd or not. 
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param> 
        private void cb_selectall_CheckedChanged(object sender, EventArgs e)
        {
            if (cb_selectall.Checked)
                for (int j = 0; j < clb_Auswahl.Items.Count; j++)
                    clb_Auswahl.SetItemChecked(j, true);
            else
                for (int j = 0; j < clb_Auswahl.Items.Count; j++)
                    clb_Auswahl.SetItemChecked(j, false);
        }

        #endregion

        #region #3# Create [Combobox Group]+ [Textgroup SelectedChanged Event]

        /// <summary>
        /// Read Text_de-DE.xml, return GroupList, und set Load Group Combobox
        /// </summary>
        /// <param name="m_path"></param>
        /// <returns></returns>
        private List<TextGroup> GroupList(string m_path)
        {
            XmlDocument doc = new XmlDocument();
            XmlNodeList GroupNodeList = null;
            // All group
            List<TextGroup> l_grouplist = new List<TextGroup>();
            TextGroup allgroup = new TextGroup("All", 0, "All Group", 0);
            l_grouplist.Add(allgroup);

            string xmlFilePath = m_path + "\\Text_de-DE.xml";
            doc.Load(xmlFilePath);
            GroupNodeList = doc.SelectNodes("/Text/TextGroup");

            int m_count = 0;                //offset of Group
            foreach (XmlNode groupNode in GroupNodeList)                //Group A-z
            {
                int g_count = int.Parse(groupNode.Attributes[1].Value); //Count of each Group
                                                                        //Console.WriteLine(l_index + sp.Name + "\t" + groupNode.Attributes[0].Value + g_count);
                TextGroup newgroup = new TextGroup(groupNode.Attributes[0].Value, g_count, groupNode.Attributes[2].Value, m_count);
                l_grouplist.Add(newgroup);

                m_count += g_count;
            }
            // Load Group Combobox-----------------------------------
            string[] GS = new string[l_grouplist.Count];
            for (int i = 0; i < l_grouplist.Count; i++)
            {
                GS[i] = "[" + l_grouplist[i].Group + "]" + l_grouplist[i].Name;
            }
            cbbGroup.Items.AddRange(GS);
            //-------------------------------------------------------

            return l_grouplist;
        }

        private void cbbGroup_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (m_cbb_groupindex != cbbGroup.SelectedIndex) group_set(cbbGroup.SelectedIndex);
            if (tb_TextFilter.Text.Length > 0)
            { 
            string filter = "%" + tb_TextFilter.Text + "%";
            Filter(filter);
            }
        }

        private void group_set(int SelectedIndex)
        {
            if (SelectedIndex != 0)
            {
                m_cbb_groupindex = SelectedIndex;
                // 02.11.2017 !! Schwerpunkt! bei Suchen der DataMenber = "a"; wird String immer als "A" verwandert.
                //1//dataGridView1.DataMember = g_list[m_groupindex].Group; 
                dataGridView1.DataSource = TextBank.Tables[m_cbb_groupindex - 1];                
                dataGridView2.DataSource = TextState.Tables[m_cbb_groupindex - 1];
                //Console.WriteLine("index:"+ TextBank.Tables.IndexOf(TextBank.Tables[g_list[m_groupindex].Group]));
                Console.Write("index{0} ;ID: {1}\n", m_cbb_groupindex, TextBank.Tables[g_list[m_cbb_groupindex].Group].Rows[0]["TextID"]);
                //#Bug12##Änderung#-----------------
                for (int t_index = 0; t_index < g_list[m_cbb_groupindex].Count; t_index++)  //探索内存表方法 e.columnsindex
                {
                    for (int l = 1; l < l_list.Count + 1; l++)
                    {
                        //TheTextStatus TTS;
                        //try
                        //{
                        //    TTS = (TheTextStatus )Enum.Parse(typeof(TheTextStatus), TextState.Tables[m_cbb_groupindex - 1].Rows[t_index][l].ToString()) ;
                        //}
                        //catch (Exception)
                        //{
                        //    continue;
                        //}
                        //if (TTS == TheTextStatus.Edited)/*.ToString()*//* ==*/ /* "3"*/ //#Bug13#
                        if (TextState.Tables[m_cbb_groupindex - 1].Rows[t_index][l].ToString() == "3") //#Bug13#
                        {
                            if (Isorignial(t_index))
                                dataGridView1.Rows[t_index].Cells[l].Style.BackColor = m_ChangedCellsColor;                            
                        }
                    }

                }
                //----------------------------------
                ResetSpaltwidth();
                //dataGridView1.Columns[1].HeaderText = dataGridView1.Columns[1].Name + "test";   //#Bug5##HeaderText#
                //Console.WriteLine(dataGridView1.Columns[1].HeaderText + ":::" + dataGridView1.Columns[1].Name);
                //SetColorofEmptyLine();
            }
        }

        private bool Isorignial(int t)
        {
            string Textid;
            try  {Textid = dataGridView1.Rows[t].Cells[0].Value.ToString();            }
            catch (Exception)
                { return false;   }
            int t_index = IDtoIndex(Textid);
            if (t == t_index) return true;
            return false;
        }
        #endregion

        #region Index of l_list, g_list

        private TextGroup group(string gname)
        {

            foreach (var gp in g_list)
            {
                if (gp.Group == gname) return gp;
            }
            throw new System.ArgumentOutOfRangeException("t");
        }

        private int Get_gl_index(TextGroup gp)
        {
            return g_list.IndexOf(gp);
        }

        private Sprache language(string lname)
        {
            foreach (var sp in l_list)
            {
                if (lname == sp.Name) return sp;
            }
            throw new System.ArgumentOutOfRangeException("t");
        }

        private int Get_ll_index(Sprache sp)
        {
            return l_list.IndexOf(sp);
        }
        #endregion

        #region MenuItem Event

        /// <summary>
        /// open-Menu Item: 
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void openToolStripMenuItem_Click(object sender, EventArgs e)
        {
            OpenFileDialog openFileDialog1 = new System.Windows.Forms.OpenFileDialog();
            openFileDialog1.InitialDirectory = Application.StartupPath /*+ "\\Text"*/;
            openFileDialog1.Filter = "xml(*.xml)|Language.xml";
            if (openFileDialog1.ShowDialog() == DialogResult.OK)
            {
                m_LangListFile = openFileDialog1.FileName;                //string m_path = Path.GetDirectoryName(m_Filename);

                l_list = Sprachelist_load(m_LangListFile);

                //AddColumnstoDataGridView();
                #region redudanz
                ////XmlDocument xmlDocument = new XmlDocument();//新建一个XML“编辑器”  
                ////xmlDocument.Load(m_File);//载入路径这个xml  
                //try
                //{
                //    //XmlNodeList xmlNodeList = xmlDocument.SelectSingleNode("class").ChildNodes;//选择class为根结点并得到旗下所有子节点  
                //    //dataGridView1.Rows.Clear();//清空dataGridView1，防止和上次处理的数据混乱  
                //    //foreach (XmlNode xmlNode in xmlNodeList)//遍历class的所有节点  
                //    //{
                //    //    XmlElement xmlElement = (XmlElement)xmlNode;//对于任何一个元素，其实就是每一个<student>  
                //    //    //旗下的子节点<name>和<number>分别放入dataGridView1  
                //    //    int index = dataGridView1.Rows.Add();//在dataGridView1新加一行，并拿到改行的行标  
                //    //    dataGridView1.Rows[index].Cells[0].Value = xmlElement.ChildNodes.Item(0).InnerText;//各个单元格分别添加  
                //    //    dataGridView1.Rows[index].Cells[1].Value = xmlElement.ChildNodes.Item(1).InnerText;
                //    //}
                //}
                //catch
                //{

                //}
                #endregion
            }
            else { }
        }

        /// <summary>
        /// Set Language visible 
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btn_SetItem_Click(object sender, EventArgs e)
        {
            if (splitContainer1.SplitterDistance > 1)
            {
                if(tabControl1.SelectedIndex == 0)
                {
                    splitContainer1.SplitterDistance = 1;
                    return;
                }
            }
                splitContainer1.SplitterDistance = 250;
                tabControl1.SelectedIndex = 0;
            
        }

        private void bt_SearchTab_Click(object sender, EventArgs e)
        {
            if (splitContainer1.SplitterDistance > 1)
            {
                if (tabControl1.SelectedIndex == 1)
                {
                    splitContainer1.SplitterDistance = 1;
                    return;
                }
            }            
                splitContainer1.SplitterDistance = 250;
                tabControl1.SelectedIndex = 1;
            
        }

        #endregion

        #region Color Menber
        //private Color m_ChangedCellsColor = Color.LightSalmon;
        private Color m_ChangedCellsColor = Color.Yellow;
        public Color ChangedCellsColor
        {
            get { return m_ChangedCellsColor; }
            set { m_ChangedCellsColor = value; }
        }

        private Color m_SavededCellsColor = Color.Lime;
        public Color SavedCellsColor
        {
            get { return m_SavededCellsColor; }
            set { m_SavededCellsColor = value; }
        }
        #endregion

        #region butten

        private void bt_NextGroup_Click(object sender, EventArgs e)
        {
            if (cbbGroup.SelectedIndex < cbbGroup.Items.Count - 1)
                cbbGroup.SelectedIndex += 1;
        }

        private void bt_LastGroup_Click(object sender, EventArgs e)
        {
            if (cbbGroup.SelectedIndex > 0)
                cbbGroup.SelectedIndex -= 1;
        }

        private void bt_NextResult_Click(object sender, EventArgs e)
        {
            if (lsb_SearchResult.SelectedIndex < lsb_SearchResult.Items.Count - 1)
            {
                lsb_SearchResult.SelectedIndex += 1;
                lsb_SearchResult_DoubleClick(sender, null);
            }

        }

        private void bt_LastResult_Click(object sender, EventArgs e)
        {
            if (lsb_SearchResult.SelectedIndex > 0)
                lsb_SearchResult.SelectedIndex -= 1;
        }

        #endregion

        #region Proporty 


        public string E_WorkDirectory
        {
            get { return m_WorkDirectory; }
            set { m_WorkDirectory = value; }
        }

        public string E_TextPath
        {
            get { return m_TextPath; }
            set { m_TextPath = value; }
        }

        public string E_LangListFile
        {
            get { return m_LangListFile; }
            set { m_LangListFile = value; }
        }
        #endregion

    #endregion
            
    #region## Dateset, Datetable; Create, Load, test

        /// <summary>
        /// Create Dataset with n-Group-Datatable, which just TextID writed.
        /// </summary>
        /// <param name="ll"></param>
        /// <param name="gl"></param>
        private void OpenTextBank(List<Sprache> ll, List<TextGroup> gl)
        {
            DataTable fdt = new DataTable("Form");
            //fdt.Columns.Add(new DataColumn("Group",typeof(string)));
            fdt.Columns.Add(new DataColumn("TextID"/*, typeof(TheTextStatus)*/));
            for (int i = 0; i < l_list.Count; i++)                          //#Bug7#
            {
                fdt.Columns.Add(new DataColumn(ll[i].Name));                //#Bug6##TableCloumnName# #Bug7#
                //fdt.Columns[i+1].
            }

            TextBank = new DataSet("TextBank");
            //TextBank.CaseSensitive = true;//#case-1#
            TextState = new DataSet("TextState");

            // Write TextID
            for (int i = 1; i < gl.Count; i++)
            {
                //  Jede Gruppen werden in eignen Tablen "A","B"......"a", "b"
                DataTable dtNew1 = new DataTable();
                dtNew1 = fdt.DefaultView.ToTable();
                dtNew1.TableName = gl[i].Group;
                DataTable dtNew2 = new DataTable();
                dtNew2 = fdt.DefaultView.ToTable();
                dtNew2.TableName = gl[i].Group;
                //  addieren leer Zeilen.
                string ID = null;
                for (int j = 0; j < gl[i].Count; j++)
                {
                    ID = dtNew1.TableName + j.ToString("000");
                    dtNew1.Rows.Add();                    //dtNew.Rows.Add(ID);                    
                    dtNew1.Rows[j]["TextID"] = ID;
                    dtNew2.Rows.Add();
                }
                TextBank.Tables.Add(dtNew1);
                TextState.Tables.Add(dtNew2);
                //Console.Write("{0}-gropu: {1}\n",i, /*gl[i].Group.ToString()*/ID + 1.ToString("000"));
                //Console.Write("ID: {0}\n", dtNew.Rows[0]["TextID"]);
                //TextState.Tables.Add(dtNew1.DefaultView.ToTable());

            }

        }

        /// <summary>
        /// Read all Text_xx_XX.xml into own Table
        /// </summary>
        private void LoadTextBank()
        {
            XmlDocument doc = new XmlDocument();
            XmlNodeList GroupNodeList = null;
            foreach (Sprache sp in l_list)          // l_list[0]=de-DE #Bug7#
            {
                int l_index = l_list.IndexOf(sp);   //#Bug7#
                string xmlFilePath = m_TextPath + "\\Text_" + sp.CultureName + ".xml";
                doc.Load(xmlFilePath);
                GroupNodeList = doc.SelectNodes("/Text/TextGroup");

                foreach (XmlNode groupNode in GroupNodeList)       // Gruppen: A,B,C
                {
                    XmlNodeList TextsNode = groupNode.SelectNodes("TextElement");
                    foreach (XmlNode TextElement in TextsNode)     // A[index] = "......"
                    {
                        int index = int.Parse(TextElement.Attributes[0].Value);
                        TextBank.Tables[groupNode.Attributes[0].Value].Rows[index][/*LNametoColName(*/sp.Name/*)*/] = TextElement.Attributes[1].Value; //#Bug6#
                        //Console.WriteLine(TextElement.Attributes[1].Value);    
                        TextState.Tables[groupNode.Attributes[0].Value].Rows[index][/*LNametoColName(*/sp.Name/*)*/] = "2";
                    }
                }
                TextBank.AcceptChanges();
                TextState.AcceptChanges();
            }

        }
          
        /// <summary>
        /// Überprüfen die Zeile von aktuelle Datatable, ob alle Textcellen keinen Text haben.
        /// </summary>
        /// <param name="dr"></param>
        /// <returns></returns>
        bool AreAllTextColumnsEmpty(DataRow dr, List<Sprache> sl) //SL Sprache List
        {
            if (dr == null)
            { return true; }
            else
            {
                for (int i = 0; i < sl.Count; i++)
                {
                    if (!string.IsNullOrEmpty(dr[/*LNametoColName(*/sl[i].Name/*)*/].ToString())) return false; //#Bug6#
                }
                return true;
            }
        }

        #endregion

        #region#4# search, replace

        #region subclass SearchTool;  TextElement(SearchResultText, TextStaus)

        public class SearchTool
        {
            private string m_FindText;
            private string m_ReplaceText;
            int language_index;
            int group_index;
            private static bool m_IgnoreCase;
            private static bool m_FindExactly;
            private static bool m_ResultOnly;

            #region Propoty
            public string FindText
            {
                get { return m_FindText; }
                set { m_FindText = value; }
            }

            public string ReplaceText
            {
                get { return m_ReplaceText; }
                set { m_ReplaceText = value; }
            }

            public int LanguageIndex
            {
                get { return language_index; }
                set { language_index = value; }
            }

            public int GroupIndex
            {
                get { return group_index; }
                set { group_index = value; }
            }

            public bool IgnoreCase
            {
                get { return m_IgnoreCase; }
                set { m_IgnoreCase = value; }
            }

            public bool FindExactly
            {
                get { return m_FindExactly; }
                set { m_FindExactly = value; }
            }
            public bool ResultOnly
            {
                get { return m_ResultOnly; }
                set { m_ResultOnly = value; }
            }
            #endregion

            public SearchTool()
            {
                m_FindText = m_instanz.tb_Find.Text;
                m_ReplaceText = m_instanz.tb_Replace.Text;
                language_index = m_instanz.cbb_SearchLanguage.SelectedIndex;
                group_index = m_instanz.cbb_SearchGroup.SelectedIndex;
                m_IgnoreCase = m_instanz.cb_IgnoreCase.Checked;
                m_FindExactly = m_instanz.cb_FindExactly.Checked;
                m_ResultOnly = m_instanz.cb_Resultonly.Checked;
            }
        }

        public abstract class TextElement
        {
            /// <summary>
            /// Konstruktor für Suchergebnisse
            /// </summary>
            public TextElement()
            {
            }

            public override string ToString()
            {
                return "- invalid entry -";
            }


            //public virtual bool Edit(System.Windows.Forms.IWin32Window Parent)
            //{
            //    return true;
            //}
        }

        public class SearchResultText : TextElement
        {
            private int l_index; //0[1,24]
            private int g_index; //[0,33]
            private int t_index; //[0,599]
            private string languageName;
            private string groupName;
            private string text;
            //private Data

            #region Propoty
            public string Text
            {
                get { return text; }
                set { text = value; }
            }

            public string GroupNamwe
            {
                get { return groupName; }
                set { groupName = value; }
            }

            public string LanguageName
            {
                get { return languageName; }
                set { languageName = value; }
            }

            public int LanguageIndex
            {
                get { return l_index; }
                set { l_index = value; }
            }

            public int GroupIndex
            {
                get { return g_index; }
                set { g_index = value; }
            }

            public int TextIndex
            {
                get { return t_index; }
                set { t_index = value; }
            }

            #endregion

            /// <summary>
            /// Konstruktor für Textergebnisse
            /// </summary>
            public SearchResultText(int l, int g, int t) : base()
            {
                l_index = l;
                g_index = g;
                t_index = t;
                languageName = l_list[l - 1].Name;
                groupName = g_list[g].Group;
                text = m_instanz.TextBank.Tables[g_index - 1].Rows[t_index][l_index].ToString();
            }

            public override string ToString()
            {
                if (text != null)
                {
                    return languageName.ToString() + ": " + groupName.ToString() + t_index.ToString("000") + ": " + text;
                }
                return base.ToString();
            }

            ///// <summary>
            ///// Ergebniss editieren
            ///// </summary>
            //public override bool Edit(System.Windows.Forms.IWin32Window Parent)
            //{
            //    if (m_textelem != null)
            //    {
            //        m_textelem.Editor.object2Edit = m_textelem;

            //        if (TextEditor.EditorTextForm.ThisInstance == null)
            //        {
            //            m_textelem.Editor.ShowDialog(Parent);
            //            return true;
            //        }
            //        else
            //        {
            //            TextEditor.EditorTextForm.ThisInstance.selectedTextID = new TextID(m_textelem.Group.Group, m_textelem.Index);
            //            return false;
            //        }

            //    }
            //    return true;
            //}
        }

        public class TextStatus : TextElement
        {
            private int l_index; //0[1,24]
            private int g_index; //[0,33]
            private int t_index; //[0,599]
            private string languageName;
            private string groupName;
            private string text;

            #region Propoty
            public string Text
            {
                get { return text; }
                set { text = value; }
            }

            public string GroupNamwe
            {
                get { return groupName; }
                set { groupName = value; }
            }

            public string LanguageName
            {
                get { return languageName; }
                set { languageName = value; }
            }

            public int LanguageIndex
            {
                get { return l_index; }
                set { l_index = value; }
            }

            public int GroupIndex
            {
                get { return g_index; }
                set { g_index = value; }
            }

            public int TextIndex
            {
                get { return t_index; }
                set { t_index = value; }
            }

            #endregion

            /// <summary>
            /// Konstruktor für Textergebnisse
            /// </summary>
            public TextStatus(int l, int g, int t) : base()
            {
                l_index = l;
                g_index = g;
                t_index = t;
                languageName = l_list[l - 1].Name;
                groupName = g_list[g].Group;
                text = m_instanz.TextBank.Tables[g_index - 1].Rows[t_index][l_index].ToString();
            }

            public override string ToString()
            {
                if (text != null)
                {
                    return languageName.ToString() + ": " + groupName.ToString() + t_index.ToString("000") + ": " + text;
                }
                return base.ToString();
            }


        }

        #endregion

        private void InitalSearchTool()
        {
            tb_Find.Text = "";
            tb_Replace.Text = "~~~";
            tb_Replace.Enabled = false;
            cb_Replace.Checked = false;
            cb_IgnoreCase.Checked = true;
            LoadSearchCombobox();
            ST = new SearchTool();
        }

        private void LoadSearchCombobox()
        {
            string[] LS = new string[l_list.Count+1];
            LS[0] = "-- all languages --";
            for (int i = 0; i < l_list.Count; i++)
            {
                LS[i + 1] = l_list[i].Name;
            }
            cbb_SearchLanguage.Items.AddRange(LS);
            cbb_SearchLanguage.SelectedIndex = 1;

            string[] GS = new string[g_list.Count];
            GS[0] = "-- all text groups --";
            for (int i = 1; i < g_list.Count; i++)
            {
                GS[i] = "[" + g_list[i].Group + "]" + g_list[i].Name;
            }
            cbb_SearchGroup.Items.AddRange(GS);
            cbb_SearchGroup.SelectedIndex = 0;
        }

        #region Search

        private void bt_Search_Click(object sender, EventArgs e)
        {
            if (tb_Find.Text.Length == 0)
            {
                bt_replace.Enabled = false;
                return;
            }
            Cursor.Current = Cursors.WaitCursor;
            //-----------
            ST.FindText = tb_Find.Text;
            ST.ReplaceText = tb_Replace.Text;
            ST.LanguageIndex = cbb_SearchLanguage.SelectedIndex;
            ST.GroupIndex = cbb_SearchGroup.SelectedIndex;
            ST.IgnoreCase = cb_IgnoreCase.Checked;
            ST.FindExactly = cb_FindExactly.Checked;
            lsb_SearchResult.Items.Clear();
            //-
            if (ST.LanguageIndex == 0)                                  // Columns[1 ~ l_list.Count+1]
            {
                for (int l = 1; l < l_list.Count + 1; l++)               //#Bug8# 
                {
                    if (ST.GroupIndex == 0)                             // Columns[1 ~ l_list.Count+1] + all groups
                    {
                        for (int g = 1; g < g_list.Count; g++)
                        {
                            for (int t = 0; t < g_list[g].Count; t++)   //each Textelement
                            {
                                AddSearchResult(l, g, t);
                            }
                        }
                    }
                    else                                                // Columns[1 ~ l_list.Count+1] + 1 groups
                    {
                        for (int t = 0; t < g_list[ST.GroupIndex].Count; t++)
                        {
                            AddSearchResult(l, ST.GroupIndex, t);
                        }
                    }
                }
            }
            else
            {
                if (ST.GroupIndex == 0)                             // Columns[ST.GroupIndex] + all groups
                {
                    for (int g = 1; g < g_list.Count; g++)
                    {
                        for (int t = 0; t < g_list[g].Count; t++)
                        {
                            AddSearchResult(ST.LanguageIndex, g, t);
                        }
                    }
                }
                else                                                   // Columns[ST.GroupIndex] + 1groups
                {
                    for (int t = 0; t < g_list[ST.GroupIndex].Count; t++)
                    {
                        AddSearchResult(ST.LanguageIndex, ST.GroupIndex, t);
                    }
                }
            }

            if (lsb_SearchResult.Items.Count == 0)
            {
                lsb_SearchResult.Items.Add("Not Found");
            }
            CanReplace();
            Cursor.Current = Cursors.Default;
            lsb_SearchResult.SetSelected(0, true);
        }

        public string GetTextElemnt(SearchResultText SText)
        {
            //string str;
            string str = SText.Text;
            if (ST.IgnoreCase)
            {
                ST.FindText = ST.FindText.ToLower();
                return str.ToLower();
            }
            else
                return str;
        }

        public bool GetFoundJudgment(string CurrentText)
        {
            if (ST.FindExactly)
                return CurrentText.Equals(ST.FindText);
            else
                return (CurrentText.IndexOf(ST.FindText) != -1);
        }

        private void AddSearchResult(int l, int g, int t)
        {
            SearchResultText SText = new SearchResultText(l, g, t);
            //string StringInText = null; //#Bug10#
            bool found;
            found = GetFoundJudgment(GetTextElemnt(SText));
            if (found)
            {
                m_instanz.lsb_SearchResult.Items.Add(SText); //#Bug7#
                //m_instanz.lsb_SearchResult.Items.Add(l_list[l-1]); //#Bug7#
            }
        }

        private void lsb_SearchResult_DoubleClick(object sender, EventArgs e)
        {
            SearchResultText result = this.lsb_SearchResult.SelectedItem as SearchResultText;

            //-------------
            string strt = tb_Find.Text;
            string TextID = result.GroupNamwe + result.TextIndex.ToString("000");
            tb_TextFilter.Clear();
            tb_Find.Text = strt;
            // change Group
            cbbGroup.SelectedIndex = result.GroupIndex;
            // Visisble test
            if (dataGridView1.Columns[result.LanguageIndex].Visible == false) dataGridView1.Columns[result.LanguageIndex].Visible = true;
            // ##full table
            if (!cb_Resultonly.Checked)
            {
                foreach (DataGridViewRow row in dataGridView1.Rows)
                {
                    if (row.Cells[0].Value.ToString() == TextID)
                        try { dataGridView1.CurrentCell = dataGridView1.Rows[row.Index].Cells[result.LanguageIndex]; }
                        catch (Exception) { }
                }

            }
            else //##just Result
            {
                tb_TextFilter.Text = strt;
                foreach (DataGridViewRow row in dataGridView1.Rows)
                {
                    if (row.Cells[0].Value.ToString() == TextID)
                    {
                        try { dataGridView1.CurrentCell = dataGridView1.Rows[row.Index].Cells[result.LanguageIndex]; }
                        catch (Exception) { }
                    }
                }
            }
        }

        #endregion

        #region Enter Key-down
        private void tb_Find_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                bt_Search_Click(bt_Search, null);
                bt_Search.Select();
            }
        }

        private void tb_Replace_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                bt_Search_Click(bt_Search, null);
                bt_Search.Select();
            }
        }

        private void tb_TextFilter_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                bt_Search_Click(bt_Search, null);
                string filter = "%" + tb_TextFilter.Text + "%";
                Filter(filter);
            }
        }
        #endregion

        #region Event option/Select/Text changed

        private void tb_Find_TextChanged(object sender, EventArgs e)
        {
            ST.FindText = tb_Find.Text;
            //tb_TextFilter.Text = tb_Find.Text;
            dataGridView1.Refresh();
        }

        private void cb_Replace_CheckedChanged(object sender, EventArgs e)
        {
            tb_Replace.Enabled = cb_Replace.Checked;
            if (!cb_Replace.Checked)
                tb_Replace.Text = "~~~";
        }

        private void cbb_SearchLanguage_SelectedIndexChanged(object sender, EventArgs e)
        {
            lb_TextFilter.Text = "Search in " + cbb_SearchLanguage.SelectedItem.ToString();
        }
        #endregion

        #region Replace
        private void bt_replace_Click(object sender, EventArgs e)
        {
            try
            {
                SearchResultText fokusText = this.lsb_SearchResult.SelectedItem as SearchResultText;
                if (tb_Replace.Text != "~~~")
                {
                    string newtext;
                    if (cb_IgnoreCase.Checked)
                    {
                        newtext = Regex.Replace(fokusText.Text, tb_Find.Text, tb_Replace.Text, RegexOptions.IgnoreCase);
                    }
                    else
                    {
                        newtext = fokusText.Text.Replace(tb_Find.Text, tb_Replace.Text);
                    }
                    m_instanz.TextBank.Tables[fokusText.GroupIndex - 1].Rows[fokusText.TextIndex][fokusText.LanguageIndex] = newtext;
                    m_instanz.TextState.Tables[fokusText.GroupIndex - 1].Rows[fokusText.TextIndex][fokusText.LanguageIndex] = "3";
                    Filter("%" + tb_Find.Text + "%");

                }
            }
            catch (Exception)
            {
                Console.WriteLine("false");
            }

            //if (replace != "~~~")


        }

        private bool CanReplace()
        {
            if (cb_Replace.Checked)
            {
                if (tb_Replace.Text != "~~~" && tb_Find.Text.Length != 0)
                {
                    if (lsb_SearchResult.Items[0].ToString() != "Not Found")
                    {
                        bt_replace.Enabled = true;
                        return true;
                    }

                }
            }
            bt_replace.Enabled = false;
            return false;
        }
        #endregion

        /// <summary>
        /// 单元格重绘 字体色 背景色
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void dataGridView1_CellFormatting(object sender, DataGridViewCellFormattingEventArgs e)
        {
            if (ST.FindText.Length > 0)
            {
                if (ST.IgnoreCase)
                {
                    if (e.Value.ToString().IndexOf(ST.FindText, StringComparison.OrdinalIgnoreCase) >= 0)
                        e.CellStyle.ForeColor = Color.DodgerBlue;
                    if (e.Value.ToString().Contains(ST.FindText))
                        e.CellStyle.ForeColor = Color.Blue;
                }
                else
                {
                    if (e.Value.ToString().Contains(ST.FindText))
                        e.CellStyle.ForeColor = Color.Blue;
                }
                //e.ColumnIndex
                //    e.RowIndex
                string Textid = dataGridView1.Rows[e.RowIndex].Cells[0].Value.ToString();
                int t_index = IDtoIndex(Textid);
                try
                {
                    if (TextState.Tables[m_cbb_groupindex - 1].Rows[t_index][e.ColumnIndex].ToString() == "3")  //#Bug13#
                    {
                        e.CellStyle.BackColor = m_ChangedCellsColor;
                    }
                }
                catch (Exception) { }

                //#markierung Änderung#
                //StringComparison.
            }

        }

        #region QuickSearch Rowfilter = ""; "=1"; ....

        private void bt_QSearch_Click(object sender, EventArgs e)
        {            
            
        }

        private void tb_TextFilter_TextChanged(object sender, EventArgs e)
        {
            tb_Find.Text = tb_TextFilter.Text;
            string filter = "%" + tb_TextFilter.Text + "%";
            Filter(filter);
        }

        private void Filter(string queryInfo)
        {
           lb_SearchStatus.Text = "";
            string filterStr = "";
            var last = l_list.Last();
            if (ST.LanguageIndex == 0)
            {
                foreach (var sp in l_list)
                {
                    if (sp.Equals(last))
                    {
                        filterStr += "[" + sp.Name + "]" + " like '{0}' "; //#Bug6##Bug7#
                        if (CanReplace()) filterStr += "or [" + sp.Name + "]" + " like '%"+tb_Replace.Text +"%' ";
                    }
                    else
                    {
                        filterStr += "[" + sp.Name + "]" + " like '{0}' or "; //#Bug6##Bug7#
                        if (CanReplace()) filterStr += "[" + sp.Name + "]" + " like '%" + tb_Replace.Text + "%' or";
                    }
                }
            }
            else
            {
                filterStr += "[" + l_list[ST.LanguageIndex-1].Name + "]" + " like '{0}' ";
               if (CanReplace()) filterStr += "or [" + l_list[ST.LanguageIndex - 1].Name + "]" + " like '%" + tb_Replace.Text + "%' ";//#Bug11#
            }
            //filterStr = "[Text_US-english] like '{0}'";

            if (string.IsNullOrEmpty(queryInfo))
            {
                filterStr = " 1=1 ";
            }
            else
            {
                filterStr = string.Format(filterStr, queryInfo);
            }

            //filterStr += "and german is not null and french is null ";

            TextBank.Tables[m_cbb_groupindex - 1].DefaultView.RowFilter = filterStr /*"Text_German like '%Sch%'"*/;  //#Bug6#
            //Not Found Situation erklärung
            if (dataGridView1.Rows.Count == 0)
            {
                lb_SearchStatus.Text = "Nou Found in " + cbb_SearchLanguage.SelectedItem.ToString();
            }
        }

        private void bt_FilterClear_Click(object sender, EventArgs e)
        {
            string temp = tb_TextFilter.Text;
            tb_TextFilter.Text = "";
            //TextBank.Tables[m_cbb_groupindex - 1].DefaultView.RowFilter = "german is not null and (chinese is null or chinese = '')";
            TextBank.Tables[m_cbb_groupindex - 1].DefaultView.RowFilter = "";
            tb_Find.Text = temp;
        }
        #endregion

        #endregion

        #region ## Text; XML; String; 

        #region Positon of XMLNode 

        /// <summary>
        /// Wählt den XmlNode(Language) von SumTexttemp.xml aus, der mit geändertem dataGridView1.Cell entspricht.  
        /// Wenn newline true wäre, gebt den Vater-Vaterknote(TextGroup) zurück.
        /// </summary>
        /// <param name="group"></param>
        /// <param name="index"></param>
        /// <param name="intNumber"></param>
        /// <param name="newline">Beurteilen, ob gearbeite Cell in leerem Zeile steht.</param>
        /// <returns></returns>
        private XmlNode GetTextNodeofChangedCell(string group, int index, int intNumber, out bool newline)
        {
            //----------------------------------------
            newline = false;
            string quere = string.Format("/Text/TextGroup[@Group='{0}']/TextElement[@Index='{1}']/Language[@IntNumber='{2}']", group, index, intNumber);
            XmlNode LTextNode = TextDoc.SelectSingleNode(quere);  //#Bug1##leerLinewrited#          
            //Console.WriteLine("TE:index{0}_Text:{1};language:{3};Text:{2}", 1, LTextNode.ParentNode.Attributes["Text"].Value, 
            //                   LTextNode.Attributes["LanguageText"].Value, l_list.Sprachelist[intNumber].CultureName);   
            if (LTextNode == null)
            {
                newline = true;
                string quere0 = string.Format("/Text/TextGroup[@Group='{0}']", group, index, intNumber);
                LTextNode = TextDoc.SelectSingleNode(quere0);
                //XmlNode gNode = LanguageDoc.ImportNode(groupNode, false);
            }
            return LTextNode;
        }

        /// <summary>
        /// Erstellen neue TextElement(Zeilen) mit Index, die vorher keine Text gibt.
        /// Geben ein XmlElement zurück.
        /// </summary>
        /// <param name="Doc">Unter welche XmlDocument</param>
        /// <param name="index"></param>
        /// <returns></returns>
        private XmlElement NewTextElement(XmlDocument Doc, int index)
        {
            XmlElement node = Doc.CreateElement("TextElement"); //#!XmlElemnt-SetAttribute#
            node.SetAttribute("Index", index.ToString());
            node.SetAttribute("Text", "");
            for (int i = 0; i < l_list.Count; i++) //#Bu7#
            {
                XmlElement language = Doc.CreateElement("Language"); //#Bug2#LanguageDesign#
                language.SetAttribute("IntNumber", i.ToString());
                language.SetAttribute("Status", "0");
                language.SetAttribute("LanguageText", "");
                node.AppendChild(language);
            }
            return node;
        }

        #endregion

        #region Text_xx_XX.xml Export in XML

        /// <summary>
        /// Geben Text_xx_XX.xml je nach Auswahl aus. 
        /// </summary>
        private void ExportAllLanguage(/*int[] Lout*/)
        {
            for (int i = 0; i < l_list.Count; i++) //#Bug7#
            {
                ExportSingleLanguage(i);
                //SaveSingleLanguage(LanguagenametoIntNumber("German"));
            }
        }

        /// <summary>
        /// Geben einzige Text_xx_XX.xml je nach InternalNumber aus. 
        /// </summary>
        /// <param name="intnumber"></param>
        private void ExportSingleLanguage(int intnumber)
        {
            //-temp--SumTexttemp.xml------
            XmlDocument SumTextDoc = new XmlDocument();
            SumTextDoc.Load(TempFileName(m_CacheFile));
            //----------------------------
            XmlDocument LanguageDoc = new XmlDocument();            
            LanguageDoc.AppendChild(LanguageDoc.CreateXmlDeclaration("1.0", "utf-8", null));
            LanguageDoc.AppendChild(LanguageDoc.CreateComment("Visu Textfile"));
            LanguageDoc.AppendChild(LanguageDoc.CreateElement("Text"));            
            //-Group---------------------
            XmlNodeList GroupNodeList = SumTextDoc.SelectNodes("/Text/TextGroup"); //#sum#
            foreach (XmlNode groupNode in GroupNodeList)                        //#sum#
            {
                XmlNode gNode = LanguageDoc.ImportNode(groupNode, false);                               //#sum->out# //#ImportNode#
                LanguageDoc.DocumentElement.AppendChild(gNode);
                //-Textelement-----------
                XmlNodeList TextsNode = groupNode.SelectNodes("TextElement");   //#sum#
                foreach (XmlNode TextNode in TextsNode)                         //#sum#
                {   
                    //-Languages IntNumber----------
                    XmlNode tNode = LanguageDoc.ImportNode(TextNode, false);                            //#sum->out#
                    string quere = string.Format("Language[@IntNumber='{0}']", intnumber);              //nach Sprache      
                    string Ltext = TextNode.SelectSingleNode(quere).Attributes["LanguageText"].Value;   //#sum->out#
                    if (!String.IsNullOrEmpty(Ltext))
                    {
                        tNode.Attributes["Text"].Value = Ltext;
                        gNode.AppendChild(tNode);
                    }
                    //else            //#Ausleitung fehlender Textblöcke#
                    //{               //Ltext ist empty
                    //    if (!String.IsNullOrEmpty(tNode.Attributes["Text"].Value))
                    //    {
                    //        tNode.Attributes["Text"].Value = Ltext;
                    //        gNode.AppendChild(tNode);
                    //    }
                    //}
                }
            }
            LanguageDoc.Save(m_ResaultDirectory+"\\Text_" + l_list[intnumber].CultureName + ".xml");
            
        }
        #endregion

        #region String Funktion; konvertieren[FileName, Path] 

        /// <summary>
        ///  returen ColumnName from LanguageName
        /// </summary>
        public string LNametoColName(string LanguageName)
        {
            return "Text_" + LanguageName[0].ToString().ToUpper() + LanguageName.Substring(1);
        }

        public string ColNametoLName(string ColumnName)
        {
            string temp = ColumnName.Substring(5);

            return temp[0].ToString().ToLower() + temp.Substring(1);
        }

        public string TempFileName(string xmlfile)
        {
            //string[] f = xmlfile.Split(new Char[] { '.' });
            //return f[0]+"temp" +"."+f[1];            
            return xmlfile.Replace(".xml", "") + "temp" + ".xml";
        }
        #endregion

        #endregion

        /// <summary>
        /// 状态监控 点击单元格 显示坐标
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void dataGridView1_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            lb_cell.Text = "Datagridview Cell: Row:" + e.RowIndex + "  cloumn:" + e.ColumnIndex;
            string ID = dataGridView1.CurrentRow.Cells[0].Value.ToString();
            if (e.RowIndex >= 0 && e.ColumnIndex > 0)
            {
                int t_index;
                int.TryParse(ID.Substring(1), out t_index);
                lb_elem.Text = string.Format("Textelemt: TextID:{0}  TextGroup:{1}  Index:{2}  Language:{3}", ID, ID[0],t_index , l_list[dataGridView1.CurrentCell.ColumnIndex - 1].Name);
            }
        }                     

        public int IDtoIndex(string id)
        {
            id = id.Substring(1);
            return int.Parse(id);
        }
        
    }    
}

//public Sprache this[string name]
//{
//    get
//    {
//        foreach (var sp in Sprachelist)
//        {
//            if (sp.Name == name) return sp;
//        }
//        throw new System.ArgumentOutOfRangeException("t");
//    }

//}
