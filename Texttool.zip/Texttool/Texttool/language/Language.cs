﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml;
using System.Windows.Forms;

namespace Texttool.language
{           
        public class Sprache
        {
            private string S_Name;
            private string S_CultureName;
            private int S_InternalNumber;
            private string S_Text;            
            private bool S_visible;


            public Sprache(string Name, string CtName, string Text, int INumber)
            {
                S_Name = Name;
                S_CultureName = CtName;
                S_Text = Text;
                S_InternalNumber = INumber;
                S_visible = true;                
            }

            public Sprache()
            {
                S_Name = string.Empty;
                S_CultureName = string.Empty;
                S_Text = string.Empty;
                S_InternalNumber = -1;
                S_visible = true;
            }

            public string Name
            {
                get { return S_Name; }
                set { S_Name = value; }
            }

            public string CultureName
            {
                get { return S_CultureName; }
                set { S_CultureName = value; }
            }

            public string Text
            {
                get { return S_Text; }
                set { S_Text = value; }
            }

            public int InternalNumber
            {
                get { return S_InternalNumber; }
                set { S_InternalNumber = value; }
            }

            public bool Visible
            {
                get { return S_visible; }
                set { S_visible = value; }
            }

            public void clear()
            {
                S_Name = string.Empty;
                S_CultureName = string.Empty;
                S_Text = string.Empty;
                S_InternalNumber = -1;
                S_visible = false;
            }
        }
  
}
