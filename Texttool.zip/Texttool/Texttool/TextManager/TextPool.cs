﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Texttool;
using Texttool.language;
using System.Xml;

namespace Texttool.TextManager
{
    //List<SpracheText> 
    class TextPool
    {
        //static List<SpracheText> ST = null;
        public static List<TextGroup> TG = null;


        public TextPool(string m_path/*, LanguageList l_list*/)
        {
            //ST = null;            
            //string xmlFilePath = m_path + "\\Text_" + "de-DE" + ".xml";
            XmlDocument doc = new XmlDocument();
            XmlNodeList GroupNodeList = null;
            TG = new List<TextGroup>();
            TextGroup allgroup = new TextGroup("All", 0, "All Group", 0);
            TG.Add(allgroup);
        }
    }
}
