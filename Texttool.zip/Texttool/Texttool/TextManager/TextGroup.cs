﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Texttool.TextManager
{
    public class TextGroup
    {
        /// <summary>
        /// "A""B"
        /// </summary>
        private string T_Group;

        /// <summary>
        /// "A""B"...Abkurz des GroupNames in ein Charakter 
        /// </summary>
        public string Group
        {
            get { return T_Group; }
            set { T_Group = value; }
        }

        /// <summary>
        /// Voll GroupName
        /// </summary>
        private string T_GroupName;
        public string Name
        {
            get { return T_GroupName; }
            set { T_GroupName = value; }
        }

        /// <summary>
        /// Count
        /// </summary>
        private int T_count;
        public int Count
        {
            get { return T_count; }
            set { T_count = value; }
        }

        private int T_offset;
        public int Offset
        {
            get { return T_offset; }
            set { T_offset = value; }
        }

        public TextGroup()//#
        {
            this.Group = string.Empty;
            this.Count = 0;
            this.Name = "";
            this.Offset = 0;
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="group"></param>
        /// <param name="count"></param>
        /// <param name="name"></param>
        /// <param name="offset">Summen der Count vorherer Gruppen </param>
        public TextGroup(string group, int count, string name, int offset)//#
        {
            this.Group = group;
            this.Count = count;
            this.Name = name;
            this.Offset = offset;
        }

    }
}
