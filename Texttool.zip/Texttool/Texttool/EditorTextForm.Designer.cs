﻿namespace Texttool
{
    partial class EditorTextForm
    {
        /// <summary>
        /// Erforderliche Designervariable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Verwendete Ressourcen bereinigen.
        /// </summary>
        /// <param name="disposing">True, wenn verwaltete Ressourcen gelöscht werden sollen; andernfalls False.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Vom Windows Form-Designer generierter Code

        /// <summary>
        /// Erforderliche Methode für die Designerunterstützung.
        /// Der Inhalt der Methode darf nicht mit dem Code-Editor geändert werden.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(EditorTextForm));
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle4 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle5 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle6 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle7 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle8 = new System.Windows.Forms.DataGridViewCellStyle();
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.projectToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.newToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.openToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.closeToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.saveToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.recentProjectsToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator1 = new System.Windows.Forms.ToolStripSeparator();
            this.exitToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.settingsToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStrip1 = new System.Windows.Forms.ToolStrip();
            this.toolStripSplitButton1 = new System.Windows.Forms.ToolStripSplitButton();
            this.panel1 = new System.Windows.Forms.Panel();
            this.bt_LastGroup = new System.Windows.Forms.Button();
            this.bt_FilterClear = new System.Windows.Forms.Button();
            this.bt_NextGroup = new System.Windows.Forms.Button();
            this.bt_QSearch = new System.Windows.Forms.Button();
            this.lb_SearchStatus = new System.Windows.Forms.Label();
            this.bt_SearchTab = new System.Windows.Forms.Button();
            this.tb_TextFilter = new System.Windows.Forms.TextBox();
            this.lb_TextFilter = new System.Windows.Forms.Label();
            this.btn_LanguageTab = new System.Windows.Forms.Button();
            this.btn_EditGroup = new System.Windows.Forms.Button();
            this.btn_NewGroup = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.cbbGroup = new System.Windows.Forms.ComboBox();
            this.lb_cell = new System.Windows.Forms.Label();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.cb_selectall = new System.Windows.Forms.CheckBox();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.clb_Auswahl = new System.Windows.Forms.CheckedListBox();
            this.btn_addLanguage = new System.Windows.Forms.Button();
            this.btn_set = new System.Windows.Forms.Button();
            this.clb_Standard = new System.Windows.Forms.CheckedListBox();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.bt_replace = new System.Windows.Forms.Button();
            this.groupBox5 = new System.Windows.Forms.GroupBox();
            this.lsb_SearchResult = new System.Windows.Forms.ListBox();
            this.bt_LastResult = new System.Windows.Forms.Button();
            this.bt_NextResult = new System.Windows.Forms.Button();
            this.bt_Search = new System.Windows.Forms.Button();
            this.groupBox4 = new System.Windows.Forms.GroupBox();
            this.cb_Resultonly = new System.Windows.Forms.CheckBox();
            this.cb_FindExactly = new System.Windows.Forms.CheckBox();
            this.cb_IgnoreCase = new System.Windows.Forms.CheckBox();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.cbb_SearchGroup = new System.Windows.Forms.ComboBox();
            this.cbb_SearchLanguage = new System.Windows.Forms.ComboBox();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.cb_Replace = new System.Windows.Forms.CheckBox();
            this.lb_find = new System.Windows.Forms.Label();
            this.tb_Replace = new System.Windows.Forms.TextBox();
            this.tb_Find = new System.Windows.Forms.TextBox();
            this.splitContainer1 = new System.Windows.Forms.SplitContainer();
            this.lb_elem = new System.Windows.Forms.Label();
            this.imageList1 = new System.Windows.Forms.ImageList(this.components);
            this.tabControl2 = new System.Windows.Forms.TabControl();
            this.tabPage3 = new System.Windows.Forms.TabPage();
            this.tabPage4 = new System.Windows.Forms.TabPage();
            this.dataGridView2 = new System.Windows.Forms.DataGridView();
            this.tbp_output = new System.Windows.Forms.TabPage();
            this.menuStrip1.SuspendLayout();
            this.toolStrip1.SuspendLayout();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.tabControl1.SuspendLayout();
            this.tabPage1.SuspendLayout();
            this.groupBox1.SuspendLayout();
            this.tabPage2.SuspendLayout();
            this.groupBox5.SuspendLayout();
            this.groupBox4.SuspendLayout();
            this.groupBox3.SuspendLayout();
            this.groupBox2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer1)).BeginInit();
            this.splitContainer1.Panel1.SuspendLayout();
            this.splitContainer1.Panel2.SuspendLayout();
            this.splitContainer1.SuspendLayout();
            this.tabControl2.SuspendLayout();
            this.tabPage3.SuspendLayout();
            this.tabPage4.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView2)).BeginInit();
            this.SuspendLayout();
            // 
            // menuStrip1
            // 
            this.menuStrip1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.projectToolStripMenuItem,
            this.settingsToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(1332, 24);
            this.menuStrip1.TabIndex = 1;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // projectToolStripMenuItem
            // 
            this.projectToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.newToolStripMenuItem,
            this.openToolStripMenuItem,
            this.closeToolStripMenuItem,
            this.saveToolStripMenuItem,
            this.recentProjectsToolStripMenuItem,
            this.toolStripSeparator1,
            this.exitToolStripMenuItem});
            this.projectToolStripMenuItem.Name = "projectToolStripMenuItem";
            this.projectToolStripMenuItem.Size = new System.Drawing.Size(56, 20);
            this.projectToolStripMenuItem.Text = "Project";
            // 
            // newToolStripMenuItem
            // 
            this.newToolStripMenuItem.Name = "newToolStripMenuItem";
            this.newToolStripMenuItem.Size = new System.Drawing.Size(155, 22);
            this.newToolStripMenuItem.Text = "New";
            // 
            // openToolStripMenuItem
            // 
            this.openToolStripMenuItem.Name = "openToolStripMenuItem";
            this.openToolStripMenuItem.Size = new System.Drawing.Size(155, 22);
            this.openToolStripMenuItem.Text = "Open";
            this.openToolStripMenuItem.Click += new System.EventHandler(this.openToolStripMenuItem_Click);
            // 
            // closeToolStripMenuItem
            // 
            this.closeToolStripMenuItem.Name = "closeToolStripMenuItem";
            this.closeToolStripMenuItem.Size = new System.Drawing.Size(155, 22);
            this.closeToolStripMenuItem.Text = "Close";
            // 
            // saveToolStripMenuItem
            // 
            this.saveToolStripMenuItem.Name = "saveToolStripMenuItem";
            this.saveToolStripMenuItem.Size = new System.Drawing.Size(155, 22);
            this.saveToolStripMenuItem.Text = "Save";
            // 
            // recentProjectsToolStripMenuItem
            // 
            this.recentProjectsToolStripMenuItem.Name = "recentProjectsToolStripMenuItem";
            this.recentProjectsToolStripMenuItem.Size = new System.Drawing.Size(155, 22);
            this.recentProjectsToolStripMenuItem.Text = "Recent Projects";
            // 
            // toolStripSeparator1
            // 
            this.toolStripSeparator1.Name = "toolStripSeparator1";
            this.toolStripSeparator1.Size = new System.Drawing.Size(152, 6);
            // 
            // exitToolStripMenuItem
            // 
            this.exitToolStripMenuItem.Name = "exitToolStripMenuItem";
            this.exitToolStripMenuItem.Size = new System.Drawing.Size(155, 22);
            this.exitToolStripMenuItem.Text = "Exit";
            // 
            // settingsToolStripMenuItem
            // 
            this.settingsToolStripMenuItem.Name = "settingsToolStripMenuItem";
            this.settingsToolStripMenuItem.Size = new System.Drawing.Size(61, 20);
            this.settingsToolStripMenuItem.Text = "Settings";
            // 
            // toolStrip1
            // 
            this.toolStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripSplitButton1});
            this.toolStrip1.Location = new System.Drawing.Point(0, 24);
            this.toolStrip1.Name = "toolStrip1";
            this.toolStrip1.Size = new System.Drawing.Size(1332, 25);
            this.toolStrip1.TabIndex = 2;
            this.toolStrip1.Text = "toolStrip1";
            // 
            // toolStripSplitButton1
            // 
            this.toolStripSplitButton1.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.toolStripSplitButton1.Image = ((System.Drawing.Image)(resources.GetObject("toolStripSplitButton1.Image")));
            this.toolStripSplitButton1.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripSplitButton1.Name = "toolStripSplitButton1";
            this.toolStripSplitButton1.Size = new System.Drawing.Size(32, 22);
            this.toolStripSplitButton1.Text = "toolStripSplitButton1";
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.Gainsboro;
            this.panel1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel1.Controls.Add(this.bt_LastGroup);
            this.panel1.Controls.Add(this.bt_FilterClear);
            this.panel1.Controls.Add(this.bt_NextGroup);
            this.panel1.Controls.Add(this.bt_QSearch);
            this.panel1.Controls.Add(this.lb_SearchStatus);
            this.panel1.Controls.Add(this.bt_SearchTab);
            this.panel1.Controls.Add(this.tb_TextFilter);
            this.panel1.Controls.Add(this.lb_TextFilter);
            this.panel1.Controls.Add(this.btn_LanguageTab);
            this.panel1.Controls.Add(this.btn_EditGroup);
            this.panel1.Controls.Add(this.btn_NewGroup);
            this.panel1.Controls.Add(this.label1);
            this.panel1.Controls.Add(this.cbbGroup);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel1.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.panel1.Location = new System.Drawing.Point(0, 49);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1332, 62);
            this.panel1.TabIndex = 5;
            // 
            // bt_LastGroup
            // 
            this.bt_LastGroup.Location = new System.Drawing.Point(597, 7);
            this.bt_LastGroup.Name = "bt_LastGroup";
            this.bt_LastGroup.Size = new System.Drawing.Size(75, 23);
            this.bt_LastGroup.TabIndex = 10;
            this.bt_LastGroup.Text = "Last";
            this.bt_LastGroup.UseVisualStyleBackColor = true;
            this.bt_LastGroup.Click += new System.EventHandler(this.bt_LastGroup_Click);
            // 
            // bt_FilterClear
            // 
            this.bt_FilterClear.Location = new System.Drawing.Point(597, 35);
            this.bt_FilterClear.Name = "bt_FilterClear";
            this.bt_FilterClear.Size = new System.Drawing.Size(75, 23);
            this.bt_FilterClear.TabIndex = 11;
            this.bt_FilterClear.Text = "Clear";
            this.bt_FilterClear.UseVisualStyleBackColor = true;
            this.bt_FilterClear.Click += new System.EventHandler(this.bt_FilterClear_Click);
            // 
            // bt_NextGroup
            // 
            this.bt_NextGroup.Location = new System.Drawing.Point(516, 7);
            this.bt_NextGroup.Name = "bt_NextGroup";
            this.bt_NextGroup.Size = new System.Drawing.Size(75, 23);
            this.bt_NextGroup.TabIndex = 9;
            this.bt_NextGroup.Text = "Next";
            this.bt_NextGroup.UseVisualStyleBackColor = true;
            this.bt_NextGroup.Click += new System.EventHandler(this.bt_NextGroup_Click);
            // 
            // bt_QSearch
            // 
            this.bt_QSearch.Location = new System.Drawing.Point(516, 35);
            this.bt_QSearch.Name = "bt_QSearch";
            this.bt_QSearch.Size = new System.Drawing.Size(75, 23);
            this.bt_QSearch.TabIndex = 10;
            this.bt_QSearch.Text = "QuickSearch";
            this.bt_QSearch.UseVisualStyleBackColor = true;
            this.bt_QSearch.Click += new System.EventHandler(this.bt_QSearch_Click);
            // 
            // lb_SearchStatus
            // 
            this.lb_SearchStatus.AutoSize = true;
            this.lb_SearchStatus.Location = new System.Drawing.Point(615, 41);
            this.lb_SearchStatus.Name = "lb_SearchStatus";
            this.lb_SearchStatus.Size = new System.Drawing.Size(0, 13);
            this.lb_SearchStatus.TabIndex = 9;
            // 
            // bt_SearchTab
            // 
            this.bt_SearchTab.Location = new System.Drawing.Point(10, 34);
            this.bt_SearchTab.Name = "bt_SearchTab";
            this.bt_SearchTab.Size = new System.Drawing.Size(111, 23);
            this.bt_SearchTab.TabIndex = 8;
            this.bt_SearchTab.Text = "Search Option";
            this.bt_SearchTab.UseVisualStyleBackColor = true;
            this.bt_SearchTab.Click += new System.EventHandler(this.bt_SearchTab_Click);
            // 
            // tb_TextFilter
            // 
            this.tb_TextFilter.Location = new System.Drawing.Point(291, 36);
            this.tb_TextFilter.Name = "tb_TextFilter";
            this.tb_TextFilter.Size = new System.Drawing.Size(219, 20);
            this.tb_TextFilter.TabIndex = 6;
            this.tb_TextFilter.TextChanged += new System.EventHandler(this.tb_TextFilter_TextChanged);
            this.tb_TextFilter.KeyDown += new System.Windows.Forms.KeyEventHandler(this.tb_TextFilter_KeyDown);
            // 
            // lb_TextFilter
            // 
            this.lb_TextFilter.AutoSize = true;
            this.lb_TextFilter.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lb_TextFilter.Location = new System.Drawing.Point(127, 37);
            this.lb_TextFilter.Name = "lb_TextFilter";
            this.lb_TextFilter.Size = new System.Drawing.Size(80, 16);
            this.lb_TextFilter.TabIndex = 7;
            this.lb_TextFilter.Text = "TextSearch:";
            this.lb_TextFilter.TextAlign = System.Drawing.ContentAlignment.TopRight;
            // 
            // btn_LanguageTab
            // 
            this.btn_LanguageTab.Location = new System.Drawing.Point(10, 7);
            this.btn_LanguageTab.Name = "btn_LanguageTab";
            this.btn_LanguageTab.Size = new System.Drawing.Size(111, 23);
            this.btn_LanguageTab.TabIndex = 5;
            this.btn_LanguageTab.Text = "Language visible";
            this.btn_LanguageTab.UseVisualStyleBackColor = true;
            this.btn_LanguageTab.Click += new System.EventHandler(this.btn_SetItem_Click);
            // 
            // btn_EditGroup
            // 
            this.btn_EditGroup.Location = new System.Drawing.Point(682, 7);
            this.btn_EditGroup.Name = "btn_EditGroup";
            this.btn_EditGroup.Size = new System.Drawing.Size(75, 23);
            this.btn_EditGroup.TabIndex = 3;
            this.btn_EditGroup.Text = "Edit Group";
            this.btn_EditGroup.UseVisualStyleBackColor = true;
            // 
            // btn_NewGroup
            // 
            this.btn_NewGroup.Location = new System.Drawing.Point(763, 6);
            this.btn_NewGroup.Name = "btn_NewGroup";
            this.btn_NewGroup.Size = new System.Drawing.Size(75, 23);
            this.btn_NewGroup.TabIndex = 4;
            this.btn_NewGroup.Text = "New Group";
            this.btn_NewGroup.UseVisualStyleBackColor = true;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(208, 9);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(77, 16);
            this.label1.TabIndex = 2;
            this.label1.Text = "Text Group:";
            // 
            // cbbGroup
            // 
            this.cbbGroup.DropDownWidth = 200;
            this.cbbGroup.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cbbGroup.FormattingEnabled = true;
            this.cbbGroup.Location = new System.Drawing.Point(291, 6);
            this.cbbGroup.Name = "cbbGroup";
            this.cbbGroup.Size = new System.Drawing.Size(219, 24);
            this.cbbGroup.TabIndex = 0;
            this.cbbGroup.SelectedIndexChanged += new System.EventHandler(this.cbbGroup_SelectedIndexChanged);
            // 
            // lb_cell
            // 
            this.lb_cell.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.lb_cell.AutoSize = true;
            this.lb_cell.Location = new System.Drawing.Point(9, 603);
            this.lb_cell.Name = "lb_cell";
            this.lb_cell.Size = new System.Drawing.Size(61, 13);
            this.lb_cell.TabIndex = 8;
            this.lb_cell.Text = "Current Cell";
            // 
            // dataGridView1
            // 
            this.dataGridView1.AllowUserToAddRows = false;
            this.dataGridView1.AllowUserToOrderColumns = true;
            dataGridViewCellStyle1.BackColor = System.Drawing.Color.Gainsboro;
            this.dataGridView1.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle1;
            this.dataGridView1.AutoSizeRowsMode = System.Windows.Forms.DataGridViewAutoSizeRowsMode.DisplayedCellsExceptHeaders;
            this.dataGridView1.CausesValidation = false;
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle2.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle2.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle2.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle2.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dataGridView1.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle2;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle3.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle3.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle3.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle3.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle3.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle3.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dataGridView1.DefaultCellStyle = dataGridViewCellStyle3;
            this.dataGridView1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dataGridView1.EnableHeadersVisualStyles = false;
            this.dataGridView1.Location = new System.Drawing.Point(3, 3);
            this.dataGridView1.Margin = new System.Windows.Forms.Padding(10);
            this.dataGridView1.Name = "dataGridView1";
            dataGridViewCellStyle4.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle4.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle4.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle4.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle4.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle4.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle4.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dataGridView1.RowHeadersDefaultCellStyle = dataGridViewCellStyle4;
            this.dataGridView1.RowHeadersVisible = false;
            this.dataGridView1.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.CellSelect;
            this.dataGridView1.Size = new System.Drawing.Size(1064, 457);
            this.dataGridView1.TabIndex = 5;
            this.dataGridView1.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView1_CellClick);
            this.dataGridView1.CellFormatting += new System.Windows.Forms.DataGridViewCellFormattingEventHandler(this.dataGridView1_CellFormatting);
            this.dataGridView1.CellValueChanged += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView1_CellValueChanged);
            this.dataGridView1.SelectionChanged += new System.EventHandler(this.dataGridView1_SelectionChanged);
            // 
            // tabControl1
            // 
            this.tabControl1.Controls.Add(this.tabPage1);
            this.tabControl1.Controls.Add(this.tabPage2);
            this.tabControl1.Controls.Add(this.tbp_output);
            this.tabControl1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tabControl1.Location = new System.Drawing.Point(0, 0);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(250, 489);
            this.tabControl1.TabIndex = 7;
            // 
            // tabPage1
            // 
            this.tabPage1.Controls.Add(this.groupBox1);
            this.tabPage1.Location = new System.Drawing.Point(4, 22);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage1.Size = new System.Drawing.Size(242, 463);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "LanguageList";
            this.tabPage1.UseVisualStyleBackColor = true;
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.cb_selectall);
            this.groupBox1.Controls.Add(this.label3);
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Controls.Add(this.clb_Auswahl);
            this.groupBox1.Controls.Add(this.btn_addLanguage);
            this.groupBox1.Controls.Add(this.btn_set);
            this.groupBox1.Controls.Add(this.clb_Standard);
            this.groupBox1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.groupBox1.Location = new System.Drawing.Point(3, 3);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(236, 457);
            this.groupBox1.TabIndex = 3;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "LanguageList";
            // 
            // cb_selectall
            // 
            this.cb_selectall.AutoSize = true;
            this.cb_selectall.Checked = true;
            this.cb_selectall.CheckState = System.Windows.Forms.CheckState.Checked;
            this.cb_selectall.Location = new System.Drawing.Point(12, 127);
            this.cb_selectall.Name = "cb_selectall";
            this.cb_selectall.Size = new System.Drawing.Size(70, 17);
            this.cb_selectall.TabIndex = 10;
            this.cb_selectall.Text = "Selcet All";
            this.cb_selectall.UseVisualStyleBackColor = true;
            this.cb_selectall.CheckedChanged += new System.EventHandler(this.cb_selectall_CheckedChanged);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(6, 107);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(110, 16);
            this.label3.TabIndex = 8;
            this.label3.Text = "Select Language";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(6, 23);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(127, 16);
            this.label2.TabIndex = 7;
            this.label2.Text = "Standard Language";
            // 
            // clb_Auswahl
            // 
            this.clb_Auswahl.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.clb_Auswahl.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.clb_Auswahl.FormattingEnabled = true;
            this.clb_Auswahl.Location = new System.Drawing.Point(8, 149);
            this.clb_Auswahl.Name = "clb_Auswahl";
            this.clb_Auswahl.Size = new System.Drawing.Size(222, 208);
            this.clb_Auswahl.TabIndex = 1;
            // 
            // btn_addLanguage
            // 
            this.btn_addLanguage.Location = new System.Drawing.Point(8, 441);
            this.btn_addLanguage.Name = "btn_addLanguage";
            this.btn_addLanguage.Size = new System.Drawing.Size(122, 23);
            this.btn_addLanguage.TabIndex = 6;
            this.btn_addLanguage.Text = "Add New Language";
            this.btn_addLanguage.UseVisualStyleBackColor = true;
            // 
            // btn_set
            // 
            this.btn_set.Location = new System.Drawing.Point(9, 369);
            this.btn_set.Name = "btn_set";
            this.btn_set.Size = new System.Drawing.Size(122, 23);
            this.btn_set.TabIndex = 2;
            this.btn_set.Text = "Set";
            this.btn_set.UseVisualStyleBackColor = true;
            this.btn_set.Click += new System.EventHandler(this.btn_set_Click);
            // 
            // clb_Standard
            // 
            this.clb_Standard.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.clb_Standard.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.clb_Standard.FormattingEnabled = true;
            this.clb_Standard.Location = new System.Drawing.Point(8, 42);
            this.clb_Standard.Name = "clb_Standard";
            this.clb_Standard.Size = new System.Drawing.Size(222, 55);
            this.clb_Standard.TabIndex = 0;
            // 
            // tabPage2
            // 
            this.tabPage2.Controls.Add(this.bt_replace);
            this.tabPage2.Controls.Add(this.groupBox5);
            this.tabPage2.Controls.Add(this.bt_LastResult);
            this.tabPage2.Controls.Add(this.bt_NextResult);
            this.tabPage2.Controls.Add(this.bt_Search);
            this.tabPage2.Controls.Add(this.groupBox4);
            this.tabPage2.Controls.Add(this.groupBox3);
            this.tabPage2.Controls.Add(this.groupBox2);
            this.tabPage2.Location = new System.Drawing.Point(4, 22);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage2.Size = new System.Drawing.Size(242, 463);
            this.tabPage2.TabIndex = 1;
            this.tabPage2.Text = "Search";
            this.tabPage2.UseVisualStyleBackColor = true;
            // 
            // bt_replace
            // 
            this.bt_replace.Enabled = false;
            this.bt_replace.Location = new System.Drawing.Point(8, 308);
            this.bt_replace.Name = "bt_replace";
            this.bt_replace.Size = new System.Drawing.Size(78, 23);
            this.bt_replace.TabIndex = 8;
            this.bt_replace.Text = "Replace";
            this.bt_replace.UseVisualStyleBackColor = true;
            this.bt_replace.Click += new System.EventHandler(this.bt_replace_Click);
            // 
            // groupBox5
            // 
            this.groupBox5.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.groupBox5.Controls.Add(this.lsb_SearchResult);
            this.groupBox5.Location = new System.Drawing.Point(3, 323);
            this.groupBox5.Name = "groupBox5";
            this.groupBox5.Size = new System.Drawing.Size(220, 134);
            this.groupBox5.TabIndex = 7;
            this.groupBox5.TabStop = false;
            // 
            // lsb_SearchResult
            // 
            this.lsb_SearchResult.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lsb_SearchResult.FormattingEnabled = true;
            this.lsb_SearchResult.Location = new System.Drawing.Point(3, 16);
            this.lsb_SearchResult.Name = "lsb_SearchResult";
            this.lsb_SearchResult.Size = new System.Drawing.Size(214, 115);
            this.lsb_SearchResult.TabIndex = 0;
            this.lsb_SearchResult.DoubleClick += new System.EventHandler(this.lsb_SearchResult_DoubleClick);
            // 
            // bt_LastResult
            // 
            this.bt_LastResult.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.bt_LastResult.Location = new System.Drawing.Point(170, 278);
            this.bt_LastResult.Name = "bt_LastResult";
            this.bt_LastResult.Size = new System.Drawing.Size(44, 23);
            this.bt_LastResult.TabIndex = 6;
            this.bt_LastResult.Text = "Last";
            this.bt_LastResult.UseVisualStyleBackColor = true;
            this.bt_LastResult.Click += new System.EventHandler(this.bt_LastResult_Click);
            // 
            // bt_NextResult
            // 
            this.bt_NextResult.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.bt_NextResult.Location = new System.Drawing.Point(123, 278);
            this.bt_NextResult.Name = "bt_NextResult";
            this.bt_NextResult.Size = new System.Drawing.Size(41, 23);
            this.bt_NextResult.TabIndex = 5;
            this.bt_NextResult.Text = "Next";
            this.bt_NextResult.UseVisualStyleBackColor = true;
            this.bt_NextResult.Click += new System.EventHandler(this.bt_NextResult_Click);
            // 
            // bt_Search
            // 
            this.bt_Search.Location = new System.Drawing.Point(8, 278);
            this.bt_Search.Name = "bt_Search";
            this.bt_Search.Size = new System.Drawing.Size(78, 23);
            this.bt_Search.TabIndex = 4;
            this.bt_Search.Text = "Search";
            this.bt_Search.UseVisualStyleBackColor = true;
            this.bt_Search.Click += new System.EventHandler(this.bt_Search_Click);
            // 
            // groupBox4
            // 
            this.groupBox4.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.groupBox4.Controls.Add(this.cb_Resultonly);
            this.groupBox4.Controls.Add(this.cb_FindExactly);
            this.groupBox4.Controls.Add(this.cb_IgnoreCase);
            this.groupBox4.Location = new System.Drawing.Point(8, 180);
            this.groupBox4.Name = "groupBox4";
            this.groupBox4.Size = new System.Drawing.Size(212, 94);
            this.groupBox4.TabIndex = 3;
            this.groupBox4.TabStop = false;
            this.groupBox4.Text = "Search criteria";
            // 
            // cb_Resultonly
            // 
            this.cb_Resultonly.AutoSize = true;
            this.cb_Resultonly.Location = new System.Drawing.Point(5, 68);
            this.cb_Resultonly.Name = "cb_Resultonly";
            this.cb_Resultonly.Size = new System.Drawing.Size(112, 17);
            this.cb_Resultonly.TabIndex = 2;
            this.cb_Resultonly.Text = "Display just Result";
            this.cb_Resultonly.UseVisualStyleBackColor = true;
            // 
            // cb_FindExactly
            // 
            this.cb_FindExactly.AutoSize = true;
            this.cb_FindExactly.Location = new System.Drawing.Point(5, 44);
            this.cb_FindExactly.Name = "cb_FindExactly";
            this.cb_FindExactly.Size = new System.Drawing.Size(79, 17);
            this.cb_FindExactly.TabIndex = 1;
            this.cb_FindExactly.Text = "find exactly";
            this.cb_FindExactly.UseVisualStyleBackColor = true;
            // 
            // cb_IgnoreCase
            // 
            this.cb_IgnoreCase.AutoSize = true;
            this.cb_IgnoreCase.Location = new System.Drawing.Point(5, 20);
            this.cb_IgnoreCase.Name = "cb_IgnoreCase";
            this.cb_IgnoreCase.Size = new System.Drawing.Size(129, 17);
            this.cb_IgnoreCase.TabIndex = 0;
            this.cb_IgnoreCase.Text = "ignore character case";
            this.cb_IgnoreCase.UseVisualStyleBackColor = true;
            // 
            // groupBox3
            // 
            this.groupBox3.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.groupBox3.Controls.Add(this.label5);
            this.groupBox3.Controls.Add(this.label4);
            this.groupBox3.Controls.Add(this.cbb_SearchGroup);
            this.groupBox3.Controls.Add(this.cbb_SearchLanguage);
            this.groupBox3.Location = new System.Drawing.Point(6, 90);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(214, 84);
            this.groupBox3.TabIndex = 2;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "Search in ...";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(7, 54);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(58, 13);
            this.label5.TabIndex = 3;
            this.label5.Text = "Text group";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(7, 26);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(55, 13);
            this.label4.TabIndex = 2;
            this.label4.Text = "Language";
            // 
            // cbb_SearchGroup
            // 
            this.cbb_SearchGroup.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.cbb_SearchGroup.FormattingEnabled = true;
            this.cbb_SearchGroup.Location = new System.Drawing.Point(106, 46);
            this.cbb_SearchGroup.Name = "cbb_SearchGroup";
            this.cbb_SearchGroup.Size = new System.Drawing.Size(100, 21);
            this.cbb_SearchGroup.TabIndex = 1;
            // 
            // cbb_SearchLanguage
            // 
            this.cbb_SearchLanguage.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.cbb_SearchLanguage.FormattingEnabled = true;
            this.cbb_SearchLanguage.Location = new System.Drawing.Point(106, 19);
            this.cbb_SearchLanguage.Name = "cbb_SearchLanguage";
            this.cbb_SearchLanguage.Size = new System.Drawing.Size(100, 21);
            this.cbb_SearchLanguage.TabIndex = 0;
            this.cbb_SearchLanguage.SelectedIndexChanged += new System.EventHandler(this.cbb_SearchLanguage_SelectedIndexChanged);
            // 
            // groupBox2
            // 
            this.groupBox2.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.groupBox2.Controls.Add(this.cb_Replace);
            this.groupBox2.Controls.Add(this.lb_find);
            this.groupBox2.Controls.Add(this.tb_Replace);
            this.groupBox2.Controls.Add(this.tb_Find);
            this.groupBox2.Location = new System.Drawing.Point(6, 2);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(214, 82);
            this.groupBox2.TabIndex = 1;
            this.groupBox2.TabStop = false;
            // 
            // cb_Replace
            // 
            this.cb_Replace.AutoSize = true;
            this.cb_Replace.Location = new System.Drawing.Point(7, 47);
            this.cb_Replace.Name = "cb_Replace";
            this.cb_Replace.Size = new System.Drawing.Size(95, 17);
            this.cb_Replace.TabIndex = 3;
            this.cb_Replace.Text = "Repalce text...";
            this.cb_Replace.UseVisualStyleBackColor = true;
            this.cb_Replace.CheckedChanged += new System.EventHandler(this.cb_Replace_CheckedChanged);
            // 
            // lb_find
            // 
            this.lb_find.AutoSize = true;
            this.lb_find.Location = new System.Drawing.Point(24, 26);
            this.lb_find.Name = "lb_find";
            this.lb_find.Size = new System.Drawing.Size(56, 13);
            this.lb_find.TabIndex = 2;
            this.lb_find.Text = "Find text...";
            // 
            // tb_Replace
            // 
            this.tb_Replace.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.tb_Replace.Location = new System.Drawing.Point(108, 45);
            this.tb_Replace.Name = "tb_Replace";
            this.tb_Replace.Size = new System.Drawing.Size(100, 20);
            this.tb_Replace.TabIndex = 1;
            this.tb_Replace.KeyDown += new System.Windows.Forms.KeyEventHandler(this.tb_Replace_KeyDown);
            // 
            // tb_Find
            // 
            this.tb_Find.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.tb_Find.Location = new System.Drawing.Point(108, 19);
            this.tb_Find.Name = "tb_Find";
            this.tb_Find.Size = new System.Drawing.Size(100, 20);
            this.tb_Find.TabIndex = 0;
            this.tb_Find.TextChanged += new System.EventHandler(this.tb_Find_TextChanged);
            this.tb_Find.KeyDown += new System.Windows.Forms.KeyEventHandler(this.tb_Find_KeyDown);
            // 
            // splitContainer1
            // 
            this.splitContainer1.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.splitContainer1.Location = new System.Drawing.Point(0, 111);
            this.splitContainer1.Name = "splitContainer1";
            // 
            // splitContainer1.Panel1
            // 
            this.splitContainer1.Panel1.BackColor = System.Drawing.Color.Gainsboro;
            this.splitContainer1.Panel1.Controls.Add(this.tabControl1);
            this.splitContainer1.Panel1.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.splitContainer1.Panel1MinSize = 1;
            // 
            // splitContainer1.Panel2
            // 
            this.splitContainer1.Panel2.Controls.Add(this.tabControl2);
            this.splitContainer1.Size = new System.Drawing.Size(1332, 489);
            this.splitContainer1.SplitterDistance = 250;
            this.splitContainer1.TabIndex = 6;
            // 
            // lb_elem
            // 
            this.lb_elem.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.lb_elem.AutoSize = true;
            this.lb_elem.Location = new System.Drawing.Point(7, 620);
            this.lb_elem.Name = "lb_elem";
            this.lb_elem.Size = new System.Drawing.Size(53, 13);
            this.lb_elem.TabIndex = 9;
            this.lb_elem.Text = "Textelemt";
            // 
            // imageList1
            // 
            this.imageList1.ColorDepth = System.Windows.Forms.ColorDepth.Depth8Bit;
            this.imageList1.ImageSize = new System.Drawing.Size(16, 16);
            this.imageList1.TransparentColor = System.Drawing.Color.Transparent;
            // 
            // tabControl2
            // 
            this.tabControl2.Controls.Add(this.tabPage3);
            this.tabControl2.Controls.Add(this.tabPage4);
            this.tabControl2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tabControl2.Location = new System.Drawing.Point(0, 0);
            this.tabControl2.Name = "tabControl2";
            this.tabControl2.SelectedIndex = 0;
            this.tabControl2.Size = new System.Drawing.Size(1078, 489);
            this.tabControl2.TabIndex = 6;
            // 
            // tabPage3
            // 
            this.tabPage3.Controls.Add(this.dataGridView1);
            this.tabPage3.Location = new System.Drawing.Point(4, 22);
            this.tabPage3.Name = "tabPage3";
            this.tabPage3.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage3.Size = new System.Drawing.Size(1070, 463);
            this.tabPage3.TabIndex = 0;
            this.tabPage3.Text = "Standard";
            this.tabPage3.UseVisualStyleBackColor = true;
            // 
            // tabPage4
            // 
            this.tabPage4.Controls.Add(this.dataGridView2);
            this.tabPage4.Location = new System.Drawing.Point(4, 22);
            this.tabPage4.Name = "tabPage4";
            this.tabPage4.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage4.Size = new System.Drawing.Size(1070, 463);
            this.tabPage4.TabIndex = 1;
            this.tabPage4.Text = "tabPage4";
            this.tabPage4.UseVisualStyleBackColor = true;
            // 
            // dataGridView2
            // 
            this.dataGridView2.AllowUserToAddRows = false;
            this.dataGridView2.AllowUserToOrderColumns = true;
            dataGridViewCellStyle5.BackColor = System.Drawing.Color.Gainsboro;
            this.dataGridView2.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle5;
            this.dataGridView2.AutoSizeRowsMode = System.Windows.Forms.DataGridViewAutoSizeRowsMode.DisplayedCellsExceptHeaders;
            this.dataGridView2.CausesValidation = false;
            dataGridViewCellStyle6.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle6.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle6.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle6.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle6.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle6.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle6.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dataGridView2.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle6;
            this.dataGridView2.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridViewCellStyle7.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle7.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle7.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle7.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle7.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle7.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle7.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dataGridView2.DefaultCellStyle = dataGridViewCellStyle7;
            this.dataGridView2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dataGridView2.EnableHeadersVisualStyles = false;
            this.dataGridView2.Location = new System.Drawing.Point(3, 3);
            this.dataGridView2.Margin = new System.Windows.Forms.Padding(10);
            this.dataGridView2.Name = "dataGridView2";
            dataGridViewCellStyle8.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle8.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle8.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle8.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle8.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle8.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle8.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dataGridView2.RowHeadersDefaultCellStyle = dataGridViewCellStyle8;
            this.dataGridView2.RowHeadersVisible = false;
            this.dataGridView2.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.CellSelect;
            this.dataGridView2.Size = new System.Drawing.Size(1064, 457);
            this.dataGridView2.TabIndex = 6;
            // 
            // tbp_output
            // 
            this.tbp_output.Location = new System.Drawing.Point(4, 22);
            this.tbp_output.Name = "tbp_output";
            this.tbp_output.Size = new System.Drawing.Size(242, 463);
            this.tbp_output.TabIndex = 2;
            this.tbp_output.Text = "Missing Text";
            this.tbp_output.UseVisualStyleBackColor = true;
            // 
            // EditorTextForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1332, 644);
            this.Controls.Add(this.lb_elem);
            this.Controls.Add(this.lb_cell);
            this.Controls.Add(this.splitContainer1);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.toolStrip1);
            this.Controls.Add(this.menuStrip1);
            this.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.MainMenuStrip = this.menuStrip1;
            this.Name = "EditorTextForm";
            this.Text = "Texteditor";
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.toolStrip1.ResumeLayout(false);
            this.toolStrip1.PerformLayout();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.tabControl1.ResumeLayout(false);
            this.tabPage1.ResumeLayout(false);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.tabPage2.ResumeLayout(false);
            this.groupBox5.ResumeLayout(false);
            this.groupBox4.ResumeLayout(false);
            this.groupBox4.PerformLayout();
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.splitContainer1.Panel1.ResumeLayout(false);
            this.splitContainer1.Panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer1)).EndInit();
            this.splitContainer1.ResumeLayout(false);
            this.tabControl2.ResumeLayout(false);
            this.tabPage3.ResumeLayout(false);
            this.tabPage4.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView2)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem projectToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem newToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem openToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem closeToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem saveToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem exitToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem settingsToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem recentProjectsToolStripMenuItem;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator1;
        private System.Windows.Forms.ToolStrip toolStrip1;
        private System.Windows.Forms.ToolStripSplitButton toolStripSplitButton1;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label label1;
        public System.Windows.Forms.ComboBox cbbGroup;
        private System.Windows.Forms.Button btn_LanguageTab;
        private System.Windows.Forms.Button btn_EditGroup;
        private System.Windows.Forms.Button btn_NewGroup;
        private System.Windows.Forms.Label lb_TextFilter;
        private System.Windows.Forms.TextBox tb_TextFilter;
        private System.Windows.Forms.Label lb_cell;
        public System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.CheckBox cb_selectall;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.CheckedListBox clb_Auswahl;
        private System.Windows.Forms.Button btn_addLanguage;
        private System.Windows.Forms.Button btn_set;
        private System.Windows.Forms.CheckedListBox clb_Standard;
        private System.Windows.Forms.TabPage tabPage2;
        private System.Windows.Forms.SplitContainer splitContainer1;
        private System.Windows.Forms.Label lb_elem;
        private System.Windows.Forms.ListBox lsb_SearchResult;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.Label lb_find;
        private System.Windows.Forms.TextBox tb_Replace;
        private System.Windows.Forms.TextBox tb_Find;
        private System.Windows.Forms.CheckBox cb_Replace;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.ComboBox cbb_SearchGroup;
        private System.Windows.Forms.ComboBox cbb_SearchLanguage;
        private System.Windows.Forms.GroupBox groupBox4;
        private System.Windows.Forms.CheckBox cb_FindExactly;
        private System.Windows.Forms.CheckBox cb_IgnoreCase;
        private System.Windows.Forms.Button bt_LastResult;
        private System.Windows.Forms.Button bt_NextResult;
        private System.Windows.Forms.Button bt_Search;
        private System.Windows.Forms.GroupBox groupBox5;
        private System.Windows.Forms.ImageList imageList1;
        private System.Windows.Forms.Button bt_SearchTab;
        private System.Windows.Forms.CheckBox cb_Resultonly;
        private System.Windows.Forms.Label lb_SearchStatus;
        private System.Windows.Forms.Button bt_replace;
        private System.Windows.Forms.Button bt_QSearch;
        private System.Windows.Forms.Button bt_FilterClear;
        private System.Windows.Forms.Button bt_LastGroup;
        private System.Windows.Forms.Button bt_NextGroup;
        private System.Windows.Forms.TabControl tabControl2;
        private System.Windows.Forms.TabPage tabPage3;
        private System.Windows.Forms.TabPage tabPage4;
        public System.Windows.Forms.DataGridView dataGridView2;
        private System.Windows.Forms.TabPage tbp_output;
    }
}

